﻿<#   
.SYNOPSIS   
Script removes scheduled by Petya ransomare tasks on a computer
#>
$task = schtasks.exe /query /v /fo csv | ConvertFrom-Csv
$task | ? {$_.'TaskName' -like "\{*" -And $_.'Task To Run' -like "*system32\shutdown.exe*"} | % {$tname = $_.'TaskName'; schtasks /DELETE /f /TN $tname}
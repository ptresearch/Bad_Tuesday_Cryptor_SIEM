$processes = Get-WmiObject Win32_Process | Where-Object -FilterScript {$_.Name -eq "rundll32.exe"} | Where-Object -FilterScript {$_.CommandLine -like "*perfc*"} 
if($processes) {
    foreach ($process in $processes) {
        Get-Process -Id $process.ProcessId | Stop-Process
    }
}
